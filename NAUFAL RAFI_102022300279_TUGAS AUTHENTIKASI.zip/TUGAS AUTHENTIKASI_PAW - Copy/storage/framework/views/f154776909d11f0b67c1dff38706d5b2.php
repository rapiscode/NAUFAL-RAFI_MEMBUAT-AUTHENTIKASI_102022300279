<!DOCTYPE html>
<html>
<head>
    <title>Daftar Produk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 2rem;
        }
        h1 {
            color: #333;
            margin-bottom: 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 0.75rem;
            text-align: left;
        }
        th {
            background-color: #f5f5f5;
        }
        .price {
            color: green;
            font-weight: bold;
        }
        .empty {
            text-align: center;
            color: #999;
            padding: 1rem;
        }
    </style>
</head>
<body>
    <h1>Daftar Produk</h1>

    <?php if($products->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Tanggal Ditambahkan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td class="price">Rp <?php echo e(number_format($product->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($product->created_at->timezone('Asia/Jakarta')->format('d M Y, H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="empty">Tidak ada produk yang tersedia.</p>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\PAW\TUGAS_LARAVEL_PAW\resources\views/products/index.blade.php ENDPATH**/ ?>