<!DOCTYPE html>
<html>
<head>
    <title>Daftar Produk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 2rem;
        }
        h1 {
            color: #333;
            margin-bottom: 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 0.75rem;
            text-align: left;
        }
        th {
            background-color: #f5f5f5;
        }
        .price {
            color: green;
            font-weight: bold;
        }
        .empty {
            text-align: center;
            color: #999;
            padding: 1rem;
        }
        .logout {
            margin-top: 2rem;
            text-align: center;
        }
        .logout form {
            display: inline;
        }
        .logout button {
            padding: 0.5rem 1rem;
            background-color: #ff4d4d;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 400px;
        }
        .logout button:hover {
            background-color: #e60000;
        }
    </style>
</head>
<body>
    <h1>Daftar Produk</h1>

    @if($products->count() > 0)
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Tanggal Ditambahkan</th>
                </tr>
            </thead>
            <tbody>
                @foreach($products as $index => $product)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $product->name }}</td>
                        <td class="price">Rp {{ number_format($product->price, 2, ',', '.') }}</td>
                        <td>{{ $product->created_at->timezone('Asia/Jakarta')->format('d M Y, H:i') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p class="empty">Tidak ada produk yang tersedia.</p>
    @endif

    <div class="logout">
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit">Logout</button>
        </form>
    </div>
</body>
</html>
